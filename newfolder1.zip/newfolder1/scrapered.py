import pandas as pd
import numpy as np
from textblob import TextBlob
import seaborn as sns
from matplotlib import pyplot as plt
import re
import spacy
from textstat.textstat import textstatistics, legacy_round
import nltk
from nltk.tokenize import word_tokenize, sent_tokenize
import requests
from bs4 import BeautifulSoup
from flask import Flask, request, jsonify, render_template
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from google.auth.transport.requests import Request

folder_id = '1aU2iIoRHLT39AFth0X9JDJQ7yBU1V-cz'

# Example of access token and refresh token
access_token = "ya29.a0AeDClZAwDYjI-x-3ulaMJPBZFndF4qVrz9tI6pSd-rQvDIrNrW7urZ4bG-AQgFJ6Zq_htxXR2xoa9VVWkCCMroKwaQK_3R-5a0WrvzyJpJdmyub_GLbHzzPLUvjTjpPcNujoR92xDHow2Wq8NyqpZsUp9cYikvtaopgjh7xxaCgYKAdkSARMSFQHGX2MiPt_9ZF9YBT6l2-a37_olVw0175"
access_token = str(access_token)  # Ensure it's treated as a string

refresh_token = "1//048RIl7RiPgpeCgYIARAAGAQSNwF-L9IrrqlK4NosXUDyO_TrVMpCO7yupIfVbobcrQZMiDBoFO5vJPQxiPAyZ7C76ABFDRGmfyo"
# Manually create credentials object
creds = Credentials(
    token=access_token,
    refresh_token=refresh_token,
    token_uri="https://oauth2.googleapis.com/token",
    client_id="407408718192.apps.googleusercontent.com",  # Replace with actual client ID
    client_secret="************"  # Replace with actual client secret
)

# Check if credentials are expired and refresh them if needed
if creds and creds.expired and creds.refresh_token:
    creds.refresh(Request())

# Initialize Google Drive API
drive_service = build('drive', 'v3', credentials=creds)

# Define the file you want to upload (e.g., a file named 'sample.txt' on your local system)
file_path = 'c:/Users/hp/Downloads/newfolder1/scrapered.py'  # Replace with your actual file path

# Ensure the file exists
try:
    with open(file_path, 'r') as f:
        print(f"File '{file_path}' exists.")
except FileNotFoundError:
    print(f"Error: The file '{file_path}' was not found.")
    exit(1)

# File metadata for Google Drive upload (specifying the folder where the file should be uploaded)
file_metadata = {
    'name': 'sample.py',  # Replace with your desired file name in Google Drive
    'parents': [folder_id]  # Specify the folder ID
}

# Upload the file to Google Drive
try:
    media = MediaFileUpload(file_path, mimetype='text/x-python')  # Replace with the correct MIME type
    file = drive_service.files().create(body=file_metadata, media_body=media, fields='id').execute()

    # Print the uploaded file ID
    print(f"File uploaded successfully! File ID: {file.get('id')}")

except Exception as e:
    print(f"Error uploading file: {e}")

# Initialize spaCy
nlp = spacy.load('en_core_web_sm')

# Initialize Flask app
app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def main():
    content_with_breaks = None
    results = {}

    if request.method == 'POST':
        # Get the URL from the form
        url = request.form.get('url')
        try:
            # Fetch and parse the webpage content
            page = requests.get(url)
            soup = BeautifulSoup(page.content, "html.parser")
            text2 = soup.title.get_text() if soup.title else ""
            text3 = soup.body.get_text() if soup.body else ""
            text1 = text2 + '\n' + text3

            # Clean and split the content into paragraphs
            paragraphs = text1.split("\n\n")
            content_with_breaks = ''.join(f"<p>{para.strip()}</p>" for para in paragraphs)

            # Tokenizing text into sentences
            sentences = sent_tokenize(text1)
            sentence_count = len(sentences)

            # Sentiment analysis
            blob = TextBlob(text1)

            # Helper functions for text analysis
            def avg_sentence_len(text):
                sentences = text.split(".")
                words = text.split(" ")
                return len(words) / max(len(sentences), 1)

            def break_sentences(text):
                doc = nlp(text)
                return list(doc.sents)

            def word_count(text):
                return len(word_tokenize(text))

            def syllables_count(text):
                return textstatistics().syllable_count(text)

            def avg_syllables_per_word(text):
                syllables = syllables_count(text)
                words = word_count(text)
                return legacy_round(float(syllables) / float(words), 1)

            def difficult_words(text):
                doc = nlp(text)
                words = [token.text for token in doc if not token.is_stop and token.is_alpha]
                difficult_words_set = {word for word in words if syllables_count(word) >= 2}
                return len(difficult_words_set)

            def dale_chall_readability_score(text):
                total_words = word_count(text)
                difficult_words_count = difficult_words(text)
                if total_words == 0:
                    return 0
                percent_difficult_words = (difficult_words_count / total_words) * 100
                return percent_difficult_words

            def gunning_fog(text):
                per_difficult_words = (difficult_words(text) / word_count(text)) * 100
                return 0.4 * (avg_sentence_len(text) + per_difficult_words)

            def avg_word_length(text):
                words = text.split()
                return sum(len(word) for word in words) / max(len(words), 1)

            def pronoun_count(text):
                pronoun_regex = re.compile(r'\b(I|we|my|ours|us)\b', re.I)
                return len(pronoun_regex.findall(text))

            def avg_words_per_sentence(text):
                sentences = sent_tokenize(text)
                word_counts = [len(word_tokenize(sentence)) for sentence in sentences]
                return sum(word_counts) / max(len(word_counts), 1)

            # Calculate results
            results = {
                'content': text1,
                'num_sentences': sentence_count,
                'sentiment': blob.sentiment,
                'avg_sentence_len': avg_sentence_len(text1),
                'word_count': word_count(text1),
                'avg_syllables_per_word': avg_syllables_per_word(text1),
                'difficult_words': difficult_words(text1),
                'dale_chall_score': dale_chall_readability_score(text1),
                'fog_index': gunning_fog(text1),
                'avg_word_length': avg_word_length(text1),
                'pronoun_count': pronoun_count(text1),
                'avg_words_per_sentence': avg_words_per_sentence(text1),
            }

        except Exception as e:
            # Handle errors gracefully
            content_with_breaks = f"<p style='color:red;'>Error fetching or processing URL: {e}</p>"

    return render_template('index.html', content_with_breaks=content_with_breaks, **results)

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=8080)
